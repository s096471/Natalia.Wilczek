#!/bin/bah

mkdir kopia-home
cd kopia-home
mkdir zad2
cd zad2
mkdir 96471
cd 96471
echo "kopia-home, zad, 96471"
>> log.txt
